// Chapter 1 of C++ How To Program
// Debugging problem

int main()
{
   int x, y, z;
   
   cout << "Enter two integer values: ";
   cin << x, y;

   if ( x > y )
      z == x - y;
   
   if ( x < y )
      z == y - x

   if ( x == y );
      z == x + y;

   cout << "The value of z is: " << z;
}
/**************************************************************************
 * (C) Copyright 2002 by Deitel & Associates, Inc. and Prentice Hall.     *
 * All Rights Reserved.                                                   *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/